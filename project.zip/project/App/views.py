from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import get_user
from .forms import CreateUserForm, dishform,workoutform,CalorieInForm,CalorieInTargetFrom,CalorieBurnTargetFrom,CalorieBurnForm
from .models import Dishes,Workout,CalorieIn,CalorieBurn,CalorieInTarget,CalorieBurnTarget
# Create your views here.
@login_required(login_url='/login')
def home(request): # dashboard for user
    if request.user.is_superuser:
          return redirect('/adminpanel')
    else:
          context={}
          context['food']=Dishes.objects.all()
          context['workout']=Workout.objects.all()
          context['user']=User.objects.all()
          context['CalorieIn']=CalorieIn.objects.filter(user=request.user)
          context['CalorieBurn']=CalorieBurn.objects.filter(user= request.user)
          context['CalorieInTarget']=CalorieInTarget.objects.filter(user= request.user)
          context['CalorieBurnTarget']=CalorieBurnTarget.objects.filter(user= request.user)
          return render(request,'userdash.html',context)

def userlogin(request): # Login Page
    if request.method == 'POST':
           username = request.POST.get('username')
           password = request.POST.get('password')

           user = authenticate(request, username = username , password = password)
           if user is not None:
               login(request,user)
               return redirect('/')
           else:
               return render(request, 'login.html')
     
    context={}
    return render(request,'login.html')

def signup(request): # Signup Page
    form = CreateUserForm()
	
    if request.method == 'POST':
          form = CreateUserForm(request.POST)
          if form.is_valid():
               form.save()
               return redirect('/login')


    context = {'form': form}
    return render(request,'signup.html',context)

@login_required(login_url='/login')
def adminpanel(request): # dashboard for admin/superuser
    if request.user.is_superuser:
          context={}
          context['food']=Dishes.objects.all()
          context['workout']=Workout.objects.all()
          context['user']=User.objects.all()
          context['CalorieIn']=CalorieIn.objects.all()
          context['CalorieBurn']=CalorieBurn.objects.all()
          context['CalorieInTarget']=CalorieInTarget.objects.all()
          context['CalorieBurnTarget']=CalorieBurnTarget.objects.all()
          return render(request,'admindash.html',context) 
    else:
        return render(request,'redirecting.html')

@login_required(login_url='/login')
def newdish(request): # dashboard for admin/superuser
    context={}
    form = dishform
    if request.user.is_superuser:
        if request.method == 'POST':
               form = dishform(request.POST, request.FILES)
               if form.is_valid():
                    form.save()
                    return redirect('/adminpanel')

               context = {'form': form}
               return render(request,'newdish.html',context) 

    else:
        return render(request,'redirecting.html')
    
    return render(request,'newdish.html')

@login_required(login_url='/login')
def newworkout(request): # dashboard for admin/superuser
    context={}
    form = workoutform
    if request.user.is_superuser:
        if request.method == 'POST':
               form = workoutform(request.POST, request.FILES)
               if form.is_valid():
                    form.save()
                    return redirect('/adminpanel')

               context = {'form': form}
               return render(request,'admindash.html',context) 
               
    else:
        return render(request,'redirecting.html')
    
    return render(request,'newworkout.html')

@login_required(login_url='/login')
def updatedish(request,pk): 
    data= Dishes.objects.get(id=pk)
    form = dishform(instance=data)
    if request.user.is_superuser:
        form = dishform(request.POST, request.FILES,instance=data)
        if form.is_valid():
            form.save()
            return redirect('/adminpanel')
        
        context={}
        context={'form':form}
        return render(request,'newdish.html',context) 
               
    else:
        return render(request,'redirecting.html')

@login_required(login_url='/login')
def deletedish(request,pk):
     data= Dishes.objects.get(id=pk)

     if request.method == 'POST':
          data.delete()
          return redirect('/adminpanel')
     
     context={}
     context={'item':data}
     if request.user.is_superuser:
          return render(request,'deletedish.html',context)

@login_required(login_url='/login')
def updateworkout(request,pk): 
    data= Workout.objects.get(id=pk)
    form = workoutform(instance=data)
    if request.user.is_superuser:
        form = workoutform(request.POST, request.FILES,instance=data)
        if form.is_valid():
            form.save()
            return redirect('/adminpanel')
        
        context={}
        context={'form':form}
        return render(request,'newworkout.html',context) 
               
    else:
        return render(request,'redirecting.html')

@login_required(login_url='/login')
def deleteworkout(request,pk):
     data= Workout.objects.get(id=pk)

     if request.method == 'POST':
          data.delete()
          return redirect('/adminpanel')
     
     context={}
     context={'item':data}
     if request.user.is_superuser:
          return render(request,'deleteworkout.html',context)

def adminout(request):
     logout(request)
     return redirect('/login')

def userout(request):
     logout(request)
     return redirect('/login')


@login_required(login_url='/login')
def calorieintake(request):
    form = CalorieInForm()
	
    if request.method == 'POST':
          form = CalorieInForm(initial={'user': request.user.username})
          form = CalorieInForm(request.POST)
          if form.is_valid():
               form.save()
               return redirect('/')
    else:
        user = get_user(request)
        form = CalorieInForm(initial={'user': user})

    context = {'form': form}
    return render(request,'caloriein.html',context)

@login_required(login_url='/login')
def calorieburn(request): # dashboard for admin/superuser
    form = CalorieBurnForm()
	
    if request.method == 'POST':
          form = CalorieBurnForm(request.POST)
          if form.is_valid():
               form.save()
               return redirect('/')
    else:
        user = get_user(request)
        form = CalorieBurnForm(initial={'user': user})

    context = {'form': form}
    return render(request,'calorieburn.html',context)         


@login_required(login_url='/login')
def calorieintakeupdate(request,pk): 
    data= CalorieIn.objects.get(id=pk)
    form = CalorieInForm(request.POST, request.FILES,instance=data)
    if form.is_valid():
        form.save()
        return redirect('/')
         
    context={}
    context={'form':form}
    return render(request,'caloriein.html',context) 
               
@login_required(login_url='/login')
def calorieburnupdate(request,pk): 
    data= CalorieBurn.objects.get(id=pk)
    form = CalorieBurnForm(request.POST, request.FILES,instance=data)
    if form.is_valid():
        form.save()
        return redirect('/')
         
    context={}
    context={'form':form}
    return render(request,'calorieburn.html',context) 

@login_required(login_url='/login')
def intaketarget(request): 
    form = CalorieInTargetFrom()
	
    if request.method == 'POST':
          form = CalorieInTargetFrom(request.POST)
          if form.is_valid():
               form.save()
               return redirect('/')
    else:
        user = get_user(request)
        form = CalorieInTargetFrom(initial={'user': user})

    context = {'form': form}
    return render(request,'intaketarget.html',context) 

@login_required(login_url='/login')
def burntarget(request): 
    form = CalorieBurnTargetFrom()
	
    if request.method == 'POST':
          form = CalorieBurnTargetFrom(request.POST)
          if form.is_valid():
               form.save()
               return redirect('/')
    else:
        user = get_user(request)
        form = CalorieBurnTargetFrom(initial={'user': user})


    context = {'form': form}
    return render(request,'burntarget.html',context)