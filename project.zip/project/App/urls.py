
from django.urls import path
from App import views

urlpatterns = [
    path("",views.home,name='home'),
    path("login",views.userlogin,name='login'),
    path("signup",views.signup,name='signup'),
    path("adminpanel",views.adminpanel,name='adminpanel'),
    path("newdish",views.newdish,name='newdish'),
    path("newworkout",views.newworkout,name='newworkout'),
    path("updatedish/<str:pk>",views.updatedish,name='updatedish'),
    path("updateworkout/<str:pk>",views.updateworkout,name='updatedish'),
    path("deletedish/<str:pk>",views.deletedish,name='deletedish'),
    path("deleteworkout/<str:pk>",views.deleteworkout,name='deletedish'),
    path("adminout",views.adminout,name='adminout'),
    path("userout",views.userout,name='userout'),
    path("calorieintake",views.calorieintake,name='calorieintake'),
    path("calorieburn",views.calorieburn,name='calorieburn'),
    path("calorieintakeupdate/<str:pk>",views.calorieintakeupdate,name='calorieintakeupdate'),
    path("calorieburnupdate/<str:pk>",views.calorieburnupdate,name='calorieburnupdate'),
    path("intaketarget",views.intaketarget,name='intaketarget'),
    path("burntarget",views.burntarget,name='burntarget'),
]

