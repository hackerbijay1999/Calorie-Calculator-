from django.db import models
from django.contrib.auth.models import User
Meals=(
        ('breakfast','breakfast'),
        ('lunch','lunch'),
        ('dinner','dinner'),
        ('snacks','snacks'),
    )
# Create your models here.
class Dishes(models.Model):
    Name = models.CharField(max_length=2000)
    calorie = models.FloatField()

    def __str__(self):
        return self.Name

class Workout(models.Model):
    Name = models.CharField(max_length=2000)
    calorie = models.FloatField()

    def __str__(self):
        return self.Name

class CalorieIn(models.Model):
    date_created =models.DateTimeField(auto_now_add=True,null=True)
    Meal = models.CharField(max_length=255,choices=Meals,default='breakfast')
    Food = models.ForeignKey(Dishes, on_delete=models.CASCADE,null=True)
    user = models.CharField(max_length=255,null=True)
    qty = models.FloatField()



class CalorieBurn(models.Model):
    user = models.CharField(max_length=255,null=True)
    date_created =models.DateTimeField(auto_now_add=True,null=True)
    workout = models.ForeignKey(Workout, on_delete=models.CASCADE,null=True)
    mins = models.FloatField()

class CalorieInTarget(models.Model):
    user = models.CharField(max_length=255,null=True)
    date_created =models.DateTimeField(auto_now_add=True,null=True)
    target = models.FloatField()

class CalorieBurnTarget(models.Model):
    user = models.CharField(max_length=255,null=True)
    date_created =models.DateTimeField(auto_now_add=True,null=True)
    target = models.FloatField()
