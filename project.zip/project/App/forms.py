from django import forms 
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Dishes, Workout, CalorieBurn,CalorieBurnTarget,CalorieIn,CalorieInTarget


class CreateUserForm(UserCreationForm):
    first_name = forms.CharField(max_length=255,required=True,widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'First Name'}))
    last_name = forms.CharField(max_length=255,required=True,widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Last Name'}))
    username = forms.CharField(max_length=255,required=True,widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Username'}))
    email = forms.EmailField(required=True,widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'E-Mail'}))
    phone_number = forms.IntegerField(required=True,widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Phone Number'}))
    password1 = forms.CharField(max_length=255,required=True,widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Enter Password','type':'password'}))
    password2 = forms.CharField(max_length=255,required=True,widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Confirm Password','type':'password'}))
    class Meta:
        model = User 
        fields = ['first_name','last_name','username','email','phone_number','password1','password2']

class dishform(forms.ModelForm):
     Name = forms.CharField(max_length=2000,required=True,widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Name of the dish'}))
     calorie = forms.FloatField(widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Name of the dish'}))
     
     class Meta:
        model = Dishes 
        fields = ['Name','calorie']

class workoutform(forms.ModelForm):
     Name = forms.CharField(max_length=2000,required=True,widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Name of workout'}))
     calorie = forms.CharField(widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Name of the dish'}))
     
     class Meta:
        model = Workout 
        fields = ['Name','calorie']

class CalorieInForm(forms.ModelForm):
     qty = forms.FloatField(widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Quantity'}))
     user = forms.CharField(max_length=255,required=True,widget=forms.TextInput(attrs={'type':'hidden'}))
     class Meta:
        model = CalorieIn 
        fields = ['user','Meal','Food','qty']

class CalorieBurnForm(forms.ModelForm):
     mins = forms.FloatField(widget=forms.TextInput(attrs={'class': 'ins','placeholder': 'Durations in mins'}))
     user = forms.CharField(max_length=255,required=True,widget=forms.TextInput(attrs={'type':'hidden'}))
     class Meta: 
        model = CalorieBurn
        fields = ['user','workout','mins']

class CalorieInTargetFrom(forms.ModelForm):
     user = forms.CharField(max_length=255,required=True,widget=forms.TextInput(attrs={'type':'hidden'}))
     class Meta:
        model = CalorieInTarget
        fields = ['user','target']

class CalorieBurnTargetFrom(forms.ModelForm):
     user = forms.CharField(max_length=255,required=True,widget=forms.TextInput(attrs={'type':'hidden'}))
     class Meta:
        model = CalorieBurnTarget
        fields = ['user','target']