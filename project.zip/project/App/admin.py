from django.contrib import admin
from .models import Dishes,Workout, CalorieIn, CalorieInTarget,CalorieBurn, CalorieBurnTarget
# Register your models here.
class Dishadmin(admin.ModelAdmin):
    list_display = ('Name', 'calorie')
    search_fields = ['Name']
    prepopulated_fields = {'Name': ('calorie',)}
admin.site.register(Dishes,Dishadmin)

class Workoutadmin(admin.ModelAdmin):
    list_display = ('Name', 'calorie')
    search_fields = ['Name']
    prepopulated_fields = {'Name': ('calorie',)}
admin.site.register(Workout,Workoutadmin)

class CalorieInadmin(admin.ModelAdmin):
    list_display = ('date_created','Meal','Food','user')
    search_fields = ['user']
admin.site.register(CalorieIn,CalorieInadmin)

class CalorieBurnadmin(admin.ModelAdmin):
    list_display = ('date_created','user','workout','mins')
    search_fields = ['user']
admin.site.register(CalorieBurn,CalorieBurnadmin)

class CalorieInTargetadmin(admin.ModelAdmin):
    list_display = ('date_created','user','target')
    search_fields = ['user']
admin.site.register(CalorieInTarget,CalorieInTargetadmin)

class CalorieBurnTargetadmin(admin.ModelAdmin):
    list_display = ('date_created','user','target')
    search_fields = ['user']
admin.site.register(CalorieBurnTarget,CalorieBurnTargetadmin)